# spotitusa
* run command git clone https://github.com/aamsalehin/spotitusa.git
* cd spotitusa
* php -S localhost:5000
